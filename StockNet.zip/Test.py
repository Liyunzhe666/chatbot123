import torch
import matplotlib.pyplot as plt
from StockNet.GetData import Data
import torch.nn.functional as F
class StockNet(torch.nn.Module):
    '''全连接3层：
    参数：in_dim输入维度
         layer2第二层隐藏层维度
         layer3第三层隐藏层维度
         out_dim输出数据的维度，默认为1'''
    def __init__(self,layer2=5,layer3=3,in_dimm=1,out_dimm=1):
        super(StockNet,self).__init__()
        self.layer_one=torch.nn.Linear(in_dimm,layer2)
        self.layer_two=torch.nn.Linear(layer2,layer3)
        self.layer_three=torch.nn.Linear(layer3,out_dimm)

    def forward(self,x):
        x=F.relu(self.layer_one(x))
        x=F.relu(self.layer_two(x))
        x=self.layer_three(x)
        return x




