import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from tqdm import tqdm
from untitled1.StockNet.GetData import Data
from torch.autograd import Variable
import numpy as np
panduan=0#是否执行预测

#用聚合数据api获取股市的信息预测今后的值，模型选取最简单的BP神经网络,经过思考决定用多项式拟合
def fun_x(par,x_val):
    '''多项式函数'''
    result_list=[]
    for value in x_val:
        result = 0
        for i,parameter in enumerate(par):
            result += parameter*value**i
        result_list.append(result)
    result_list=torch.Tensor(result_list)
    return result_list

def unfiformization_fun(x):
    x=(x-torch.mean(x))/torch.std(x)
    return x

def restore_pre(pred,original_y):
    pred=pred*np.std(original_y)+np.mean(original_y)
    return pred


def fun_y(x):
    '''自定义拟合函数式子'''
    result=x**2+torch.randn(x.shape)
    return result

#网络的定义--全连接3层
class StockNet(torch.nn.Module):
    '''全连接3层：
    参数：in_dim输入维度
         layer2第二层隐藏层维度
         layer3第三层隐藏层维度
         out_dim输出数据的维度，默认为1'''
    def __init__(self,layer2=20,in_dimm=1,out_dimm=1):
        super(StockNet,self).__init__()
        self.layer_one=torch.nn.Linear(in_dimm,layer2)
        self.layer_four=torch.nn.Linear(layer2,out_dimm)

    def forward(self,x):
        x=F.leaky_relu(self.layer_one(x))
        x=self.layer_four(x)
        return x
#定义网络参数
# terms=int(input('请输入为了拟合所需要的多项式项数:'))
learning_rate=float(input("输入学习率:"))
epoch=int(input("输入训练次数:"))

#这里用来做数据测试

data_x=torch.unsqueeze(torch.linspace(0,100,100),dim=1)

# 制作data真实数据
data=Data()
data_y=data.getData()
data_y=data_y.view(data_y.shape[0],-1)

# #使用自定义的加入高斯噪音的函数
# data_y=fun_y(data_x)
# data_y=data_y.view(data_y.shape[0],-1)

#网络示例化
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
model=StockNet().to(device)
optimizer=torch.optim.SGD(model.parameters(),lr=learning_rate)
loss_fun=torch.nn.MSELoss()
#对数据进行归一化处理

x=unfiformization_fun(data_x.to(device))
y=unfiformization_fun(data_y.to(device))


model.train()
loss_data=[]

figure,ax=plt.subplots(ncols=2)

axis_x=data_x.cpu().detach().numpy()
axis_y=data_y.cpu().detach().numpy()
plt.ion()
for t in tqdm(range(epoch)):

        prediction_parameters=model(x)

        loss=loss_fun(prediction_parameters,y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


        if t%100==0:
            # print('现在是第{}次训练，Loss={}'.format(t,loss))
            loss_data.append(loss)
            ax[0].set_title('loss situation')
            ax[0].set_xlabel('iter_times')
            ax[0].set_ylabel('Loss')
            ax[0].set_ylim((0,1))
            ax[0].plot(loss_data)

            plt.cla()
            ax[1].set_title('Fitting situation')
            ax[1].set_xlabel('axis X')
            ax[1].set_ylabel('axis Y')

            ax[1].scatter(axis_x,axis_y,c='r',label='real data')
            ax[1].plot(axis_x,restore_pre(prediction_parameters.cpu().detach().numpy(),axis_y),'b+-',label='fitting fun')
            plt.legend()
            plt.pause(0.1)



torch.save(StockNet,'StockNet.pkl')

# plt.subplot(1,2,1)
# plt.title('Fitting situation')
# plt.xlabel('time')
# plt.ylabel('money')
# data_x=data_x.cpu().detach().numpy()
# data_y=data_y.cpu().detach().numpy()
# prediction_parameters=prediction_parameters.cpu().detach().numpy()
# plt.scatter(data_x,data_y)
# plt.plot(data_x,prediction_parameters)

#预测未来趋势
if panduan==1:
    ##此处为预测
    model.eval()
    data_x_new=torch.unsqueeze(torch.linspace(0,150,150),dim=1).to(device)
    pre=model(data_x_new)
    data_x_new=data_x_new.cpu()
    pre=pre.cpu()

    plt.title('prediction situation')
    plt.xlabel('time/day')
    plt.ylabel('money')
    ax[1][0].plot(data_x_new.detach().numpy(),pre.detach().numpy())
    plt.ioff()
    plt.show()



